<?php
return [
    'submit'  => 'Submit',
    'ok'      => 'OK',
    'abort'   => 'Abort',
    'cancel'  => 'Cancel',
    'confirm' => 'Confirm',
    'close'   => 'Close',
    'yes'     => 'Yes',
    'no'      => 'No',
];