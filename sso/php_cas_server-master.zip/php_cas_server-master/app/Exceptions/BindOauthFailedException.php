<?php
/**
 * Created by PhpStorm.
 * User: leo108
 * Date: 16/9/20
 * Time: 21:42
 */

namespace App\Exceptions;

class BindOauthFailedException extends \Exception
{

}