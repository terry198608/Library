<?php
return [
    'submit'  => '提交',
    'ok'      => '确认',
    'abort'   => '放弃',
    'cancel'  => '取消',
    'confirm' => '确认',
    'close'   => '关闭',
    'yes'     => '是',
    'no'      => '否',
];