<?php
/**
 * Created by PhpStorm.
 * User: leo108
 * Date: 2016/10/1
 * Time: 13:52
 */

namespace App\Exceptions;

class InvalidArgumentException extends \InvalidArgumentException
{

}