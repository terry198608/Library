<?php
/**
 * Created by PhpStorm.
 * User: leo108
 * Date: 16/9/20
 * Time: 13:30
 */

namespace App\Exceptions;

class UserException extends \Exception
{

}